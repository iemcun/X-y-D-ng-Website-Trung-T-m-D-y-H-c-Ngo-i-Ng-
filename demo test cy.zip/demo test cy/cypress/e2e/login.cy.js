describe('Hệ thống Quản lý Thư viện - Full Test Suite', () => {

  // 1. KHAI BÁO TÀI KHOẢN DÙNG CHUNG CHO TẤT CẢ TEST CASE
  const TEST_ACCOUNT = {
    name: 'Hao Cypress',
    email: 'cypress@email.com',
    pass: '123456'
  };

  // Cấu hình chạy trước mỗi Test Case
  beforeEach(() => {
    // Xóa sạch dữ liệu cũ để tránh xung đột
    cy.clearLocalStorage();
    // Truy cập web
    cy.visit('https://web-qlythuviet-test.netlify.app/');
  });

  //TEST ĐĂNG KÝ
  describe('1. Chức năng Đăng ký', () => {

    it('TC01: Đăng ký thành công với tài khoản chung', () => {
      cy.contains('button', 'Register').click();
      
      // Sử dụng biến TEST_ACCOUNT đã khai báo ở tk mk
      cy.get('#reg-name').type(TEST_ACCOUNT.name);
      cy.get('#reg-email').type(TEST_ACCOUNT.email);
      cy.get('#reg-pass').type(TEST_ACCOUNT.pass);

      const stub = cy.stub();
      cy.on('window:alert', stub);

      cy.get('.btn-register').click().then(() => {
        expect(stub.getCall(0)).to.be.calledWith('Đăng ký thành công!');
      });

      // Kiểm tra sau khi đăng ký phải điền sẵn email
      cy.get('#login-form').should('not.have.class', 'hidden');
      cy.get('#login-email').should('have.value', TEST_ACCOUNT.email);
    });

    it('TC02: Đăng ký thất bại nếu sai định dạng email', () => {
      cy.contains('button', 'Register').click();
      cy.get('#reg-name').type('User Fail');
      cy.get('#reg-email').type('email-sai-format'); 
      cy.get('#reg-pass').type(TEST_ACCOUNT.pass);

      const stub = cy.stub();
      cy.on('window:alert', stub);

      cy.get('.btn-register').click().then(() => {
        expect(stub.getCall(0)).to.be.calledWith('Email không hợp lệ!');
      });
    });
  });

  //TEST ĐĂNG NHẬP
  describe('2. Chức năng Đăng nhập', () => {
    beforeEach(() => {
      // "Bơm" tài khoản cypress@email.com vào bộ nhớ trình duyệt
      cy.window().then((win) => {
        win.localStorage.setItem('libraryUsers', JSON.stringify([TEST_ACCOUNT]));
      });
    });

    it('TC03: Đăng nhập thành công với tài khoản đã tạo', () => {
      cy.get('#login-email').type(TEST_ACCOUNT.email);
      cy.get('#login-pass').type(TEST_ACCOUNT.pass);
      cy.get('.btn-login').click();

      // Kiểm tra đăng nhập thành công
      cy.get('#app-screen').should('be.visible');
      cy.get('#welcome-msg').should('contain', `Chào mừng ${TEST_ACCOUNT.name}`);
    });

    it('TC04: Đăng nhập thất bại khi sai mật khẩu', () => {
      cy.get('#login-email').type(TEST_ACCOUNT.email);
      cy.get('#login-pass').type('sai_mat_khau_ne'); // Nhập sai pass
      
      const stub = cy.stub();
      cy.on('window:alert', stub);

      cy.get('.btn-login').click().then(() => {
      expect(stub.getCall(0)).to.be.calledWith('Email hoặc mật khẩu không chính xác!');
      });
    });
  });

  //TEST TÌM KIẾM, MƯỢN SÁCH & Ls
  describe('3. Chức năng App (Tìm kiếm & Mượn)', () => {
    beforeEach(() => {
//tao csdl
      cy.window().then((win) => {
        win.localStorage.setItem('libraryUsers', JSON.stringify([TEST_ACCOUNT]));
      });

      //Thực hiện Login nhanh
      cy.get('#login-email').type(TEST_ACCOUNT.email);
      cy.get('#login-pass').type(TEST_ACCOUNT.pass);
      cy.get('.btn-login').click();
    });

    it('TC05: Tìm kiếm sách thành công', () => {
      cy.get('#search-input').type('Tâm'); // Tìm "Đắc Nhân Tâm"
      cy.get('.book-card').should('have.length', 1);
      cy.get('.book-card').first().should('contain', 'Đắc Nhân Tâm');
    });
    it('TC 5.5: Tìm kiếm sách thất bại (Không có kết quả)', () => {
      cy.get('#search-input').type('Z'); 
      cy.get('.book-card').should('have.length', 0);
      cy.get('#no-result').should('not.have.class', 'hidden');
      cy.get('#no-result').should('contain', 'Không tìm thấy cuốn sách nào phù hợp');
    });
   it('TC06: Mượn sách thành công', () => {
      cy.get('#menu-home').click(); 
      cy.wait(500);

      //Mượn sách
      cy.get('#btn-1').should('be.visible').click();//hienejnuts mượn sách
      cy.get('#borrow-modal').should('be.visible');
      cy.get('#modal-book-title').should('contain', 'Sapiens: Lịch Sử Loài Người');
      //Xác nhận
      const stub = cy.stub();
      cy.on('window:alert', stub);
      
      cy.get('.btn-confirm').click().then(() => {
        expect(stub.getCall(0)).to.be.calledWith('Gửi yêu cầu thành công sách: Sapiens: Lịch Sử Loài Người');
      });
//ktr nut
      cy.get('#btn-1').should('have.class', 'borrowed');
      cy.get('#btn-1').should('contain', 'Đang chờ duyệt');
    });

    it('TC07: Kiểm tra Lịch sử mượn (Persistence)', () => {
      //ktr lsu (Đắc Nhân Tâm)
      cy.get('#btn-2').click();
      cy.get('.btn-confirm').click();

      cy.reload();
      //dnlai
      cy.get('#login-email').type(TEST_ACCOUNT.email);
      cy.get('#login-pass').type(TEST_ACCOUNT.pass);
      cy.get('.btn-login').click();

      // 4. VàoLịch sử
      cy.get('#menu-history').click();

      // 5. Kiểm tra sách đã mượn có nằm trong list không
      cy.get('tbody#history-list tr').should('exist');
      cy.get('tbody#history-list').contains('Đắc Nhân Tâm');
      cy.get('tbody#history-list').contains('Đang chờ duyệt');
    });
  });

});